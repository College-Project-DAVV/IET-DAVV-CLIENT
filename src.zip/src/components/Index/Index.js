import React from 'react'

// import Teacherinfo from '../Teacherinfo/teacherinfo'
import styles from './Index.module.scss'

import Landing from '../Landing/Landing'

export default function Index() {
  return (
    <div className={styles.Landing}>
            <Landing />
          </div>
  )
}
