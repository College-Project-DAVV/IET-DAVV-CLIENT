import React from 'react'

import styles from './Analytics.module.scss';

const Analytics = () => {
  return (
    <div>Analytics</div>
  )
}

export default Analytics