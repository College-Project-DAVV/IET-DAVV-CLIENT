import React from 'react'
import styles from './PopUpComponent.module.scss'

const PopUpComponent = () => {
  return (
    <div>PopUpComponent</div>
  )
}

export default PopUpComponent